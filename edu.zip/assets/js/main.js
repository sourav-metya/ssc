$(document).ready(function() {
    new Swiper('#tab-swiper', {
        loop: false,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 5,
        paginationClickable: true,
        spaceBetween: 10,
        breakpoints: {
            767: {
                slidesPerView: 4,
                spaceBetween: 10
            },
        
            480: {
                slidesPerView: 4,
                spaceBetween: 10
            }
        }
    });
    new Swiper('#tab-swiper-date', {
        loop: false,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 6,
        paginationClickable: true,
        spaceBetween: 10,
        breakpoints: {

        
            480: {
                slidesPerView: 6,
                spaceBetween: 3
            }
        }
    });
    // Swiper: Slider
        new Swiper('.swiper-container', {
            loop: false,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            slidesPerView: 6,
            paginationClickable: true,
            spaceBetween: 10,
            breakpoints: {

            
                767: {
                    slidesPerView: 5,
                    spaceBetween: 10
                },
            
                480: {
                    slidesPerView: 4,
                    spaceBetween: 10
                }
            }
        });

        new Swiper('#vodotab-swiper', {
            loop: false,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            slidesPerView: 'auto', // Auto width for slides
            spaceBetween: 10, // Default space between slides
            pagination: {
                clickable: true,
            },
            breakpoints: {
                768: { // For tablets in portrait
                    slidesPerView: 4,
                    spaceBetween: 8,
                },
                640: { // For larger phones
                    slidesPerView: 3,
                    spaceBetween: 6,
                },
                480: { // For small phones
                    slidesPerView: 2,
                    spaceBetween: 6,
                },
                320: { // For very small devices
                    slidesPerView: 1,
                    spaceBetween: 5,
                },
            },
        });        
        
   
    });
    
    // tab
    $(document).ready(function(){ 
        $('.tab-a').click(function(){  
          $(".tab").removeClass('tab-active');
          $(".tab[data-id='"+$(this).attr('data-id')+"']").addClass("tab-active");
          $(".tab-a").removeClass('active-a');
          $(this).parent().find(".tab-a").addClass('active-a');
         });
    });